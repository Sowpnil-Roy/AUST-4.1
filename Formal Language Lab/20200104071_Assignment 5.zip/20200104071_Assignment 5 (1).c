#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char str[100];
int i = 0, len;
int f = 0;

void X()
{
    if(i == len - 1)
    {
        f = 1;
    }
    else if (i < len - 1 && str[i] == 'b')
    {
        i++;
        if (str[i] == 'b')
        {
            i++;
            X();
        }
        else if (str[i] == 'c')
        {
            i++;
            X();
        }
        else
        {
            f = 0;
        }
    }
    else
    {
        f = 0;
    }
}

void A()
{
    if (str[i] == 'a')
    {
        i++;
        X();
        if (f)
        {
            if (str[len - 1] == 'd')
            {
                f = 1;
                return;
            }
            else
            {
                f = 0;
                return;
            }
        }
    }
    else
    {
        f = 0;
        return;
    }
}

int main()
{
    printf("Enter The string: ");
    gets(str);
    len = strlen(str);

    A();
    if(f)
        printf("Accepted by Grammar.\n");
    else
        printf("Rejected by Grammar.\n");

    return 0;
}
