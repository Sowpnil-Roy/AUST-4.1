#include <stdio.h>

void removeCommentsWhiteSpace(FILE *input, FILE *output) {
    int c, prevChar = EOF;

    while ((c = fgetc(input)) != EOF) {
        if (c == '/') {
            int nextChar = fgetc(input);

            // Single-line comment
            if (nextChar == '/') {
                while ((c = fgetc(input)) != '\n' && c != EOF);
                continue;
            }
            // Multi-line comment
            else if (nextChar == '*') {
                int commentClosed = 0;
                while (1) {
                    c = fgetc(input);
                    if (c == '*' && fgetc(input) == '/') {
                        commentClosed = 1;
                        break;
                    } else if (c == EOF) {
                        break;
                    }
                }
                if (commentClosed == 0) {
                    fprintf(stderr, "Error: Unclosed multi-line comment.\n");
                    return;
                }
                continue;
            } else {
                fputc('/', output);
                prevChar = nextChar;
                continue;
            }
        }
        // Remove white spaces
        if (!isspace(c)) {
            fputc(c, output);
        } else if (prevChar != ' ' && prevChar != EOF) {
            fputc(' ', output);
        }
        prevChar = c;
    }
}

int main() {
    FILE *input, *output;
    char inputFileName[] = "input1.c";
    char outputFileName[] = "output.txt";

    // Open input file
    input = fopen(inputFileName, "r");
    if (input == NULL) {
        fprintf(stderr, "Error: Unable to open input file.\n");
        return 1;
    }

    // Open output file
    output = fopen(outputFileName, "w");
    if (output == NULL) {
        fprintf(stderr, "Error: Unable to open output file.\n");
        fclose(input);
        return 1;
    }

    // Remove comments and white spaces
    removeCommentsWhiteSpace(input, output);

    // Close files
    fclose(input);
    fclose(output);

    // Display both files
    printf("Original code (from %s):\n", inputFileName);
    input = fopen(inputFileName, "r");
    int c;
    while ((input != NULL) && ((c = fgetc(input)) != EOF)) {
        putchar(c);
    }
    fclose(input);

    printf("\n\nFiltered code (written to %s):\n", outputFileName);
    output = fopen(outputFileName, "r");
    while ((output != NULL) && ((c = fgetc(output)) != EOF)) {
        putchar(c);
    }
    fclose(output);

    return 0;
}
